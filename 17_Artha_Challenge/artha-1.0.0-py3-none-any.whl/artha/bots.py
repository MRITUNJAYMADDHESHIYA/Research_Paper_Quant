"""The reference field, and the Bot class participants subclass."""

from __future__ import annotations

import numpy as np

from .market import intraday_profile


class Bot:
    """Subclass this. The only method that matters is on_bar.

        class MyBot(Bot):
            def on_bar(self, state):
                return {"ASHVAM": 120.0, "BRIHAT": -90.0}

    Positive buys, negative sells. Anything you do not name trades zero. Orders
    that push past the mandate, or onto the wrong side of it, are rejected and
    logged; six rejections disqualify the run.
    """

    def on_bar(self, state) -> dict[str, float]:
        raise NotImplementedError


def _even(state, sym):
    """Split what is left evenly across the bars that remain."""
    return state.remaining[sym] / max(state.bars_left, 1)


class TWAP(Bot):
    """Equal quantity every bar. Ignores volume entirely."""

    def on_bar(self, state):
        return {s: _even(state, s) for s in state.instruments}


class VWAPForecast(Bot):
    """Follows the mean intraday profile. Knows the shape, not this session."""

    def __init__(self):
        self.profile = None

    def on_bar(self, state):
        if self.profile is None or len(self.profile) != state.n_bars:
            self.profile = intraday_profile(state.n_bars)
        ahead = self.profile[state.bar:].sum()
        w = self.profile[state.bar] / ahead if ahead > 0 else 1.0
        return {s: state.remaining[s] * w for s in state.instruments}


class FlatWeighted(Bot):
    """Schedules on the cube root of forecast volume.

    Flatter than VWAP, and empirically cheaper on impact under this generator
    because per-bar volatility rises with volume. Not the true optimum: with
    C_t = K*sigma_t*q_t^1.5 / sqrt(V_t), the first-order condition gives
    q_t proportional to V_t / sigma_t^2.
    """

    def __init__(self):
        self.w = None

    def on_bar(self, state):
        if self.w is None or len(self.w) != state.n_bars:
            p = intraday_profile(state.n_bars) ** (1 / 3)
            self.w = p / p.sum()
        ahead = self.w[state.bar:].sum()
        f = self.w[state.bar] / ahead if ahead > 0 else 1.0
        return {s: state.remaining[s] * f for s in state.instruments}


class POV(Bot):
    """Constant percentage of the previous bar's volume."""

    def __init__(self, rate: float = 0.10):
        self.rate = rate

    def on_bar(self, state):
        out = {}
        for s in state.instruments:
            v = state.last_volume[s] or 0.0
            want = self.rate * v
            rem = state.remaining[s]
            out[s] = np.sign(rem) * min(want, abs(rem))
            if state.bars_left <= 1:
                out[s] = rem
        return out


class Aggressive(Bot):
    """Takes half of every bar until done.

    This is the bot the acceptance test is about. Note that aggression is defined
    by PARTICIPATION, not by clock position: on a J-shaped profile the open is
    where the liquidity is, so "trade early" is close to volume-following and
    would not fail the way the rules intend.
    """

    def __init__(self, rate: float = 0.50):
        self.rate = rate

    def on_bar(self, state):
        out = {}
        for s in state.instruments:
            rem = state.remaining[s]
            v = state.last_volume[s]
            if not v:                       # first bar has no prior print
                out[s] = rem / max(state.bars_left, 1)
                continue
            out[s] = np.sign(rem) * min(self.rate * v, abs(rem))
        return out


class BackLoader(Bot):
    """Idles, then dumps into the close. Pays for the exposure it carries."""

    def on_bar(self, state):
        start = int(0.85 * state.n_bars)
        if state.bar < start:
            return {}
        left = max(state.n_bars - state.bar, 1)
        return {s: state.remaining[s] / left for s in state.instruments}


class Adaptive(Bot):
    """Profile-following that stretches out when realised volume undershoots."""

    def __init__(self, cap: float = 0.12):
        self.cap = cap
        self.profile = None

    def on_bar(self, state):
        if self.profile is None or len(self.profile) != state.n_bars:
            self.profile = intraday_profile(state.n_bars)
        out = {}
        for s in state.instruments:
            rem = state.remaining[s]
            if state.bars_left <= 1:
                out[s] = rem
                continue
            hist = state.volume_history[s]
            ahead = self.profile[state.bar:].sum()
            w = self.profile[state.bar] / ahead if ahead > 0 else 1.0
            want = rem * w
            # Cap against recently observed liquidity rather than the forecast.
            # When volume collapses, `recent` falls and the bot stretches out
            # instead of paying square-root impact into a thin book.
            if len(hist) >= 5:
                recent = float(np.mean(hist[-20:]))
                want = np.sign(rem) * min(abs(want), self.cap * recent)
            out[s] = want
        return out


REFERENCE_FIELD = {
    "ref:twap": TWAP,
    "ref:vwap": VWAPForecast,
    "ref:pov10": lambda: POV(0.10),
    "ref:aggressive": lambda: Aggressive(0.50),
    "ref:backload": BackLoader,
    "ref:adaptive": Adaptive,
}


def build_reference_field() -> dict:
    return {name: ctor() for name, ctor in REFERENCE_FIELD.items()}
