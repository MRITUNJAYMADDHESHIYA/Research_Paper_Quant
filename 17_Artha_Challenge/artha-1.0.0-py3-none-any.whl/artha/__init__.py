"""Artha -- execution competition engine and participant SDK.

The same package runs the server and ships to teams, so a local score and a
leaderboard score come from identical code.

    from artha import Bot, evaluate

    class MyBot(Bot):
        def on_bar(self, state):
            return {s: state.remaining[s] / max(state.bars_left, 1)
                    for s in state.instruments}

    print(evaluate(MyBot, n_paths=200))
"""

from __future__ import annotations

import numpy as np

from . import config
from .bots import Bot, build_reference_field
from .engine import BarState, run_session
from .market import Session, generate_session
from .score import combine, decompose
from .weights import calibrate as calibrate_reference

__all__ = [
    "Bot", "BarState", "Session", "config",
    "run_session", "generate_session", "decompose", "combine",
    "calibrate_reference", "evaluate",
]

__version__ = "1.0.0"


def evaluate(bot_factory, n_paths: int = 200, seed: int = 0, blocks=None,
             with_field: bool = True, weights: dict | None = None) -> dict:
    """Score a bot over `n_paths` generated sessions against the reference field.

    This is what `artha run` calls and what the server calls for the public
    leaderboard, so a team's local number is the number they will see.
    """
    rng = np.random.default_rng(seed)
    rows, legs_last = [], None

    for i in range(n_paths):
        session = generate_session(rng, blocks=blocks, path_id=f"p{i:05d}")
        agents = {"you": bot_factory()}
        if with_field:
            agents.update(build_reference_field())
        # Half the field takes the opposite side. With one-way flow the field's
        # permanent impact is a predictable drift and racing it becomes a
        # dominant strategy -- see engine.run_session.
        mandates = {}
        for i, nm in enumerate(agents):
            sgn = 1 if (nm == "you" or i % 2 == 0) else -1
            mandates[nm] = {s: sgn * session.mandate[s] for s in session.instruments}
        res = run_session(session, agents, mandates=mandates)
        comp = decompose(session, res["you"]["schedule"], res["_field"],
                         mandate=mandates["you"])
        comp["disqualified"] = res["you"]["disqualified"]
        comp["n_rejections"] = len(res["you"]["rejections"])
        legs_last = comp.pop("legs")
        rows.append(comp)

    table = {k: np.array([r[k] for r in rows], float)
             for k in ("impact", "crowding", "exposure", "carry", "timing",
                       "penalty", "shortfall", "filled")}
    w = weights or config.WEIGHTS
    scores = np.array([combine({k: r[k] for k in r if k != "legs"}, w) for r in rows])

    return dict(
        score=float(scores.mean()),
        stderr=float(scores.std(ddof=1) / np.sqrt(max(len(scores), 1))),
        components={k: float(v.mean()) for k, v in table.items()},
        weights=w,
        n_paths=n_paths,
        disqualified=any(r["disqualified"] for r in rows),
        rejections=int(sum(r["n_rejections"] for r in rows)),
        last_legs=legs_last,
    )
