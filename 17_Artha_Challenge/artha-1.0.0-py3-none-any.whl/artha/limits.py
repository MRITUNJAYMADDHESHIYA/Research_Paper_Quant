"""Submission gating: daily quota, cooldown and phase.

Pure functions over explicit state. Checks are ordered so the constraint that
outlasts the others is the one reported.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import zoneinfo

from . import config as C


@dataclasses.dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str = ""
    retry_after_s: int = 0
    remaining_today: int = 0
    """Quota left BEFORE this request is counted. `GET /me` reports it directly;
    the submit endpoint decrements it once the row is written. Returning the
    post-submission figure here made a rejected upload look as though it had
    consumed quota."""

    def as_http(self) -> tuple[int, dict]:
        """(status, body) for the API layer."""
        if self.allowed:
            return 202, {"remaining_today": self.remaining_today}
        code = 429 if self.retry_after_s else 403
        return code, {"detail": self.reason, "retry_after": self.retry_after_s,
                      "remaining_today": self.remaining_today}


def competition_day(when: dt.datetime) -> dt.date:
    """The calendar day a timestamp belongs to, in the competition's timezone."""
    tz = zoneinfo.ZoneInfo(C.COMPETITION_TZ)
    if when.tzinfo is None:
        when = when.replace(tzinfo=dt.timezone.utc)
    return when.astimezone(tz).date()


def _next_midnight(when: dt.datetime) -> dt.datetime:
    tz = zoneinfo.ZoneInfo(C.COMPETITION_TZ)
    local = when.astimezone(tz)
    tomorrow = local.date() + dt.timedelta(days=1)
    return dt.datetime.combine(tomorrow, dt.time.min, tzinfo=tz)


def check(
    now: dt.datetime,
    accepted_today: int,
    last_accepted_at: dt.datetime | None,
    phase: str = "public",
    disqualified: bool = False,
) -> Decision:
    """May this team submit right now?

    accepted_today:   submissions already ACCEPTED FOR EVALUATION today. Uploads
                      rejected at validation are not counted -- they consume no
                      compute and reveal no score, and charging a ten-minute
                      cooldown for a typo teaches nothing.
    last_accepted_at: when the previous accepted submission was taken, or None.
    """
    remaining = max(C.MAX_SUBMISSIONS_PER_DAY - accepted_today, 0)

    if disqualified:
        return Decision(False, "Team is disqualified for this round.", 0, remaining)

    if phase != "public":
        msg = {"practice": "The public leaderboard is not open yet. Keep using "
                           "`artha run` locally.",
               "private": "Submissions are closed. The private evaluation is "
                          "running on your last accepted bot.",
               "ended": "The round has ended."}.get(phase, f"Phase '{phase}' is not open.")
        return Decision(False, msg, 0, remaining)

    # Quota before cooldown: the daily cap outlasts the ten minutes, so it is the
    # constraint worth reporting.
    if remaining <= 0:
        wait = int((_next_midnight(now) - now).total_seconds())
        return Decision(
            False,
            f"Daily limit reached ({C.MAX_SUBMISSIONS_PER_DAY} per day). "
            f"Resets at midnight {C.COMPETITION_TZ}.",
            wait, 0)

    if last_accepted_at is not None:
        elapsed = (now - last_accepted_at).total_seconds()
        if elapsed < C.PUBLIC_COOLDOWN_S:
            wait = int(round(C.PUBLIC_COOLDOWN_S - elapsed))
            return Decision(
                False,
                f"Cooldown: {_human(wait)} until your next submission. "
                f"Use `artha run` in the meantime — it scores on the same engine.",
                wait, remaining)

    return Decision(True, "", 0, remaining)


def _human(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s" if s else f"{m}m"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"
