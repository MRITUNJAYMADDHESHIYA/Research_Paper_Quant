"""
The participant command line.

    artha run mybot.py              score locally, 200 paths, full decomposition
    artha run mybot.py --paths 50   faster iteration
    artha submit mybot.py           send to the public leaderboard
    artha benchmark                 score the six house bots you are measured against

Teams should almost never need the server. Local scoring uses the same engine and
the same reference field as the leaderboard, so the number printed here is the
number that appears there.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import pathlib
import sys
import urllib.error
import urllib.request

from . import evaluate
from .bots import Bot, build_reference_field

SERVER = os.environ.get("ARTHA_SERVER", "https://artha-consi.live")
BAR = "█"


def _load_bot(path: str):
    """Import a .py file and find the Bot subclass in it."""
    p = pathlib.Path(path).resolve()
    if not p.exists():
        sys.exit(f"no such file: {p}")
    spec = importlib.util.spec_from_file_location("submission", p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    found = [v for v in vars(mod).values()
             if isinstance(v, type) and issubclass(v, Bot) and v is not Bot]
    if not found:
        sys.exit(f"{p.name} defines no subclass of artha.Bot")
    if len(found) > 1:
        sys.exit(f"{p.name} defines {len(found)} bots; keep exactly one")
    return found[0]


def _fmt(res: dict, title: str) -> str:
    c, w = res["components"], res["weights"]
    out = [f"\n  {title}", f"  {'-' * 58}"]
    out.append(f"  {'SCORE':<14}{res['score']:>10.3f}  bps   "
               f"(+/- {res['stderr']:.3f} over {res['n_paths']} paths)")
    out.append("")
    out.append(f"  {'component':<14}{'bps':>10}{'weight':>10}{'contribution':>15}")
    for k in ("impact", "crowding", "exposure", "carry"):
        out.append(f"  {k:<14}{c[k]:>10.2f}{w[k]:>10.3f}{w[k] * c[k]:>15.2f}")
    out.append(f"  {'timing':<14}{c['timing']:>10.2f}{'--':>10}{'not scored':>15}")
    if c["penalty"] > 1e-9:
        out.append(f"  {'penalty':<14}{c['penalty']:>10.2f}{'1.000':>10}"
                   f"{c['penalty']:>15.2f}   << mandate unfilled")
    out.append("")
    out.append(f"  {'filled':<14}{c['filled'] * 100:>9.1f}%")
    out.append(f"  {'shortfall':<14}{c['shortfall']:>10.2f}  bps   (timing+impact+crowding)")
    if res["rejections"]:
        out.append(f"  {'rejections':<14}{res['rejections']:>10}")
    if res["disqualified"]:
        out.append("\n  DISQUALIFIED — too many rejected orders")
    return "\n".join(out)


def _diagnosis(res: dict) -> str:
    """Say which term cost the most, in words. The leaderboard number is not the
    lesson; the decomposition is."""
    c, w = res["components"], res["weights"]
    contrib = {k: w[k] * c[k] for k in ("impact", "crowding", "exposure", "carry")}
    worst = max(contrib, key=contrib.get)
    hints = {
        "impact": "You are paying for your own footprint. Either you are taking too "
                  "much of each bar, or your volume forecast is putting size into "
                  "thin bars. Look at participation, not schedule shape.",
        "crowding": "You are trading when the field trades. The cost is the whole "
                    "bar's congestion, not your share of it.",
        "exposure": "You are finishing late. Everything still outstanding is "
                    "exposed to drift, and that is charged whether or not the "
                    "drift went your way.",
        "carry": "Your legs are out of step. Finishing one before another leaves "
                 "an unhedged position the mandate never asked you to hold.",
    }
    return f"\n  Largest cost: {worst}\n  {hints[worst]}\n"


def cmd_run(args):
    bot = _load_bot(args.bot)
    res = evaluate(bot, n_paths=args.paths, seed=args.seed)
    print(_fmt(res, f"{pathlib.Path(args.bot).name}  vs reference field"))
    print(_diagnosis(res))
    if args.json:
        pathlib.Path(args.json).write_text(json.dumps(
            {k: v for k, v in res.items() if k != "last_legs"}, indent=2))
        print(f"  wrote {args.json}\n")


def cmd_benchmark(args):
    print("\n  The six house bots, scored exactly the way you are.")
    print("  These are the field you trade against on the public leaderboard.\n")
    rows = []
    for name, ctor in build_reference_field().items():
        r = evaluate(lambda c=ctor: c(), n_paths=args.paths, seed=1)
        rows.append((name, r["score"], r["components"]))
    rows.sort(key=lambda x: x[1])
    print(f"  {'bot':<18}{'score':>9}{'impact':>9}{'crowding':>10}{'exposure':>10}")
    print(f"  {'-' * 58}")
    for name, sc, c in rows:
        print(f"  {name:<18}{sc:>9.2f}{c['impact']:>9.2f}"
              f"{c['crowding']:>10.2f}{c['exposure']:>10.2f}")
    print()


def cmd_submit(args):
    bot = _load_bot(args.bot)                       # fail fast before uploading
    src = pathlib.Path(args.bot).read_text()
    token = os.environ.get("ARTHA_TOKEN")
    if not token:
        sys.exit("set ARTHA_TOKEN to your team token first")
    print(f"  validating {bot.__name__} locally ...")
    quick = evaluate(bot, n_paths=10, seed=0)
    if quick["disqualified"]:
        sys.exit("  local run disqualified — fix rejections before submitting")
    print(f"  local score {quick['score']:.2f} bps over 10 paths — uploading")

    req = urllib.request.Request(
        f"{SERVER}/submissions",
        data=json.dumps({"filename": pathlib.Path(args.bot).name, "source": src}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = json.load(r)
    except urllib.error.HTTPError as e:
        sys.exit(f"  server rejected the submission: {e.code} {e.read().decode()[:200]}")
    except urllib.error.URLError as e:
        sys.exit(f"  cannot reach {SERVER}: {e.reason}")
    print(f"  queued as submission #{body.get('id')} — "
          f"{body.get('remaining_today')} submissions left today\n")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="artha", description=__doc__.split("\n")[1])
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="score a bot locally")
    r.add_argument("bot")
    r.add_argument("--paths", type=int, default=200)
    r.add_argument("--seed", type=int, default=0)
    r.add_argument("--json", help="also write the result to this file")
    r.set_defaults(fn=cmd_run)

    d = sub.add_parser("benchmark", help="score the six house bots")
    d.add_argument("--paths", type=int, default=60)
    d.set_defaults(fn=cmd_benchmark)

    s = sub.add_parser("submit", help="send a bot to the leaderboard")
    s.add_argument("bot")
    s.set_defaults(fn=cmd_submit)

    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
