"""Market impact: a per-bar concession and a per-session displacement."""

from __future__ import annotations

import numpy as np

from .config import K_PERM, K_TEMP


def temporary_bps(participation, sigma_bar_bps):
    """Concession paid on a bar's own fill. ~38 bps at half a bar's volume."""
    return K_TEMP * np.sqrt(np.abs(participation)) * sigma_bar_bps


def permanent_bps(flow, session_volume, sigma_session_bps):
    """Per-bar increment of the midpoint displacement, signed with the flow.

    Scales with order size against SESSION volume, not bar volume: summed over a
    session an order worth 10% of volume displaces the mid about 35 bps.
    """
    return K_PERM * np.asarray(flow, float) / session_volume * sigma_session_bps


def walk_mid(base, flow, session_volume, sigma_session_bps):
    """Midpoint path after permanent impact. Bar t's displacement is felt from
    t+1, so an order does not move the price it trades at."""
    g = permanent_bps(flow, session_volume, sigma_session_bps) / 1e4
    return np.asarray(base, float) * np.exp(np.cumsum(g) - g)


def fill_prices(base, net_flow, gross_flow, own, volume, sigma_bar_bps, sigma_session_bps):
    """Prices at which `own` fills.

    Permanent impact runs off NET flow: only imbalance displaces a price.
    Temporary runs off GROSS: a bar's liquidity is consumed regardless of
    direction, so five agents taking 10% each pay the concession for 50%.
    """
    volume = np.asarray(volume, float)
    mid = walk_mid(base, net_flow, volume.sum(), sigma_session_bps)
    h = temporary_bps(np.asarray(gross_flow, float) / volume, sigma_bar_bps) / 1e4
    return mid * (1.0 + np.sign(own) * h), mid
