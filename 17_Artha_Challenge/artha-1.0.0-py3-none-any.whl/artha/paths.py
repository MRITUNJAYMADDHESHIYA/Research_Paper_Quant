"""Path packs: the frozen evaluation sets.

Every team must be scored on byte-identical paths, so packs are generated once and
never regenerated mid-round. Nothing in a pack identifies its source: bars are
indexed 0..N-1, prices are renormalised, volume is generated.
"""

from __future__ import annotations

import pathlib

import numpy as np

from . import config as C
from .market import Session

import os

SHIPPED = pathlib.Path(__file__).parent / "packs"
"""Ships inside the wheel. Holds train.npz and nothing else."""

SERVER_PACKS = pathlib.Path(os.environ.get(
    "ARTHA_PACKS", pathlib.Path(__file__).parent.parent / "data" / "packs"))
"""Server-only, OUTSIDE the package. public.npz and private.npz live here.

Keeping them in the package directory was a live hazard: `pip install .` from a
source checkout, a stray `cp -r`, or anyone reading the tree would carry the
evaluation sets along with the code, and publishing either one ends the
competition. The split makes leaking them require intent rather than
inattention."""


def pack_path(split: str) -> pathlib.Path:
    return (SHIPPED if split == "train" else SERVER_PACKS) / f"{split}.npz"


def write_pack(sessions: list[Session], path: pathlib.Path) -> None:
    syms = sessions[0].instruments
    stack = lambda attr: np.stack(
        [np.stack([getattr(s, attr)[k] for k in syms]) for s in sessions]).astype(np.float32)
    np.savez_compressed(
        path,
        instruments=np.array(syms),
        base=stack("base"),
        volume=stack("volume"),
        sigma_bar=stack("sigma_bar"),
        mandate=np.array([[s.mandate[k] for k in syms] for s in sessions], np.float32),
        shock_at=np.array([-1 if s.shock_at is None else s.shock_at for s in sessions], np.int32),
        path_id=np.array([s.path_id for s in sessions]),
    )


def read_pack(path: pathlib.Path) -> list[Session]:
    z = np.load(path, allow_pickle=False)
    syms = tuple(str(x) for x in z["instruments"])
    out = []
    for i in range(z["base"].shape[0]):
        shock = int(z["shock_at"][i])
        out.append(Session(
            instruments=syms,
            base={k: z["base"][i, j].astype(float) for j, k in enumerate(syms)},
            volume={k: z["volume"][i, j].astype(float) for j, k in enumerate(syms)},
            sigma_bar={k: z["sigma_bar"][i, j].astype(float) for j, k in enumerate(syms)},
            mandate={k: float(z["mandate"][i, j]) for j, k in enumerate(syms)},
            shock_at=None if shock < 0 else shock,
            path_id=str(z["path_id"][i]),
        ))
    return out


_CACHE: dict[str, list[Session]] = {}


def load(split: str = "train") -> list[Session]:
    """Load a split's pack, cached. `train` ships with the package; `public` and
    `private` exist only on the server."""
    if split in _CACHE:
        return _CACHE[split]
    p = pack_path(split)
    if not p.exists():
        raise FileNotFoundError(
            f"no pack for split '{split}' at {p}. "
            + ("The training pack ships with the package; reinstall artha."
               if split == "train" else
               "Run tools/build_packs.py, or set ARTHA_PACKS to the directory "
               "holding it. Evaluation packs are server-only and are never "
               "distributed."))
    _CACHE[split] = read_pack(p)
    return _CACHE[split]


def available() -> list[str]:
    out = [p.stem for p in SHIPPED.glob("*.npz")]
    if SERVER_PACKS.exists():
        out += [p.stem for p in SERVER_PACKS.glob("*.npz")]
    return sorted(set(out))


def summary(split: str = "train") -> dict:
    s = load(split)
    return {
        "split": split,
        "paths": len(s),
        "bars": s[0].n_bars,
        "instruments": list(s[0].instruments),
        "with_shock": sum(x.shock_at is not None for x in s),
        "shock_rate": round(sum(x.shock_at is not None for x in s) / len(s), 3),
        "expected_shock_rate": C.SHOCK_PROB,
    }
